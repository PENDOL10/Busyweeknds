

<?php $__env->startSection('content'); ?>
<main class="bg-white mt-12">
    <div class="px-4 md:px-18 py-12 mt-12 mx-2">
        <h1 class="text-4xl font-bold text-black">All Product</h1>
    </div>

    <div class="px-4 md:px-18 mx-2 flex flex-col lg:flex-row gap-12">
        <aside class="w-full lg:w-1/5">
            <form action="<?php echo e(route('shop')); ?>" method="GET" id="shop-filter-form">
                <div class="mb-8 text-black">
                    <h2 class="text-2xl font-bold mb-4">Category</h2>
                    <ul class="space-y-2">
                        <li><a href="<?php echo e(route('shop', array_merge(request()->except('category'), ['page' => 1]))); ?>" class="hover:underline <?php echo e(!request('category') ? 'font-bold' : ''); ?>">All</a></li>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('shop', array_merge(request()->except('category', 'page'), ['category' => $category->slug]))); ?>" 
                                   class="hover:underline <?php echo e(request('category') == $category->slug ? 'font-bold' : ''); ?>">
                                    <?php echo e($category->name); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <div class="text-black">
                    <h2 class="text-2xl font-bold mb-4">Size</h2>
                    <ul class="space-y-2">
                        <li><a href="<?php echo e(route('shop', array_merge(request()->except('size'), ['page' => 1]))); ?>" class="hover:underline <?php echo e(!request('size') ? 'font-bold' : ''); ?>">All Sizes</a></li>
                        <?php $__currentLoopData = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'One Size']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('shop', array_merge(request()->except('size', 'page'), ['size' => $sizeOption]))); ?>" 
                                   class="hover:underline <?php echo e(request('size') == $sizeOption ? 'font-bold' : ''); ?>">
                                    <?php echo e($sizeOption); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </form>
        </aside>

        <section class="w-full lg:w-4/5">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="product-card mb-12">
                        <?php
                            // Logika untuk menentukan path gambar yang benar
                            $imageUrl = '';
                            if ($product->image) {
                                // Cek apakah path dimulai dengan 'products/' (dari storage)
                                if (str_starts_with($product->image, 'products/')) {
                                    $imageUrl = asset('storage/' . $product->image);
                                } else { // Asumsi path lain adalah dari public/assets
                                    $imageUrl = asset($product->image);
                                }
                            } else {
                                $imageUrl = 'https://via.placeholder.com/300x400?text=No+Image'; // Placeholder jika tidak ada gambar
                            }
                        ?>
                        
                        <?php if(Auth::check()): ?>
                            <a href="<?php echo e(route('product.show', $product->id)); ?>" class="block">
                                <div class="mb-4 overflow-hidden">
                                    <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($product->name); ?>" class="w-auto h-auto object-cover hover:scale-105 transition-transform duration-300">
                                </div>
                                <h3 class="text-black font-bold mb-1 text-xl text-center"><?php echo e($product->name); ?></h3>
                                <p class="text-black text-reguler text-center">IDR <?php echo e(number_format($product->price, 0, ',', '.')); ?></p>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="block">
                                <div class="mb-4 overflow-hidden">
                                    <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($product->name); ?>" class="w-auto h-auto object-cover hover:scale-105 transition-transform duration-300">
                                </div>
                                <h3 class="text-black font-bold mb-1 text-xl text-center"><?php echo e($product->name); ?></h3>
                                <p class="text-black text-reguler text-center">IDR <?php echo e(number_format($product->price, 0, ',', '.')); ?></p>
                                <p class="text-blue-500 text-center mt-2">
                                    Login to view details
                                </p>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-3 text-center py-12">
                        <p class="text-xl text-gray-500">No products available matching your criteria.</p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="mt-8">
                <?php echo e($products->links()); ?>

            </div>
        </section>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\busyweeknds\resources\views/customer-user/shop.blade.php ENDPATH**/ ?>